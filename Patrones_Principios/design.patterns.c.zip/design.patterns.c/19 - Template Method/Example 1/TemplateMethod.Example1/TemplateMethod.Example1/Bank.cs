﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemplateMethod.Example1
{
    public class Bank : HiringProcess
    {
        public override void ConductInterview()
        {
            Console.WriteLine("Conducting interview about banking knowledge.");
        }      

        public override void IssueOffer()
        {
            Console.WriteLine("Issuing job offer.");
        }

        public override void ReceiveCV()
        {
            Console.WriteLine("Receiving CV for Bank.");
        }
    }
}
