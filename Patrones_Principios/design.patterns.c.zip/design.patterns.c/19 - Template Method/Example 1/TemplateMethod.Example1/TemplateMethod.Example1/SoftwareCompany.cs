﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemplateMethod.Example1
{
    public class SoftwareCompany : HiringProcess
    {
        public override void ConductInterview()
        {
            Console.WriteLine("Conducting technical interview.");
        }

        public override void ConductSkillTest()
        {
            Console.WriteLine("Conducting coding test.");
        }

        public override void IssueOffer()
        {
            Console.WriteLine("Issuing job offer.");
        }

        public override void ReceiveCV()
        {
            Console.WriteLine("Receiving CV for Software Company.");
        }
    }
}
