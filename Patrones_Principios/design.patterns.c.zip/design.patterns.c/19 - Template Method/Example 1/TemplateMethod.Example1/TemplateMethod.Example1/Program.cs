﻿using TemplateMethod.Example1;

var softwareCompany = new SoftwareCompany();
softwareCompany.HireCandidate();

var bank = new Bank();
bank.HireCandidate();