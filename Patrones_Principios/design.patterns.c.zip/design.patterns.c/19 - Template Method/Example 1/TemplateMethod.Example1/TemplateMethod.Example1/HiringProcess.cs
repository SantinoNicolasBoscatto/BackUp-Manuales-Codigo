﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemplateMethod.Example1
{
    public abstract class HiringProcess
    {
        public void HireCandidate()
        {
            ReceiveCV();
            ConductInterview();
            ConductSkillTest();
            IssueOffer();
        }

        public abstract void ReceiveCV();
        public abstract void ConductInterview();
        public virtual void ConductSkillTest()
        {
            //This might be skipped by the concrete classes
        }
        public abstract void IssueOffer();
    }
}
