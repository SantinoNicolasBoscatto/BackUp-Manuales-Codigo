﻿using TemplateMethod.Example2;

var carbonara = new SpaghettiCarbonara();
carbonara.CookPastaDish();

var alfredo = new RavioliAlfredo();
alfredo.CookPastaDish();

