﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemplateMethod.Example2
{
    public class RavioliAlfredo : PastaDish
    {
        public override void AddCheese()
        {
            Console.WriteLine("Adding parmesan cheese");
        }

        public override void AddProtein()
        {
            Console.WriteLine("Adding chicken");
        }

        public override void AddSauce()
        {
            Console.WriteLine("Adding alfredo sauce");
        }
    }
}
