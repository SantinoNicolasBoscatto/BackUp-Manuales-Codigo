﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemplateMethod.Example2
{
    public abstract class PastaDish
    {
        public void CookPastaDish()
        {
            BoilWater();
            AddPasta();
            Drain();
            AddSauce();
            AddProtein();
            AddCheese();
        }

        public void BoilWater()
        {
            Console.WriteLine("Boiling water");
        }
        public void AddPasta()
        {
            Console.WriteLine("Adding pasta");
        }
        public void Drain()
        {
            Console.WriteLine("Draining water");
        }
        public abstract void AddSauce();

        public abstract void AddProtein();

        public abstract void AddCheese();
    }
}
