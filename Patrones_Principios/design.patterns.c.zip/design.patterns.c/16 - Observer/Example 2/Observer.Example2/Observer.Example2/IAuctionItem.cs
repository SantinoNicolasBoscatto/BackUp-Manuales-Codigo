﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer.Example2
{
    public interface IAuctionItem
    {
        void RegisterBidder(IBidder bidder);
        void RemoveBidder(IBidder bidder);
        void NotifyBidders();
        void NewBid(float price, IBidder bidder);
    }
}
