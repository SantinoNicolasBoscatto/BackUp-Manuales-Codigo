﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer.Example2
{
    public class AuctionItem : IAuctionItem
    {
        private List<IBidder> _bidders = new List<IBidder>();
        private IBidder _highestBidder;

        public string Name { get; private set; }
        public float Price { get; private set; }

        public AuctionItem(string name, float startingPrice)
        {
            Name = name;
            Price = startingPrice;
        }
        public void NewBid(float price, IBidder bidder)
        {
            if (price > Price)
            {
                Price = price;
                _highestBidder = bidder;
                NotifyBidders();
            }
        }

        public void NotifyBidders()
        {
            foreach (IBidder bidder in _bidders)
            {
                bidder.Update(this);
            }
        }

        public void RegisterBidder(IBidder bidder)
        {
            _bidders.Add(bidder);
        }

        public void RemoveBidder(IBidder bidder)
        {
            _bidders.Remove(bidder);
        }
    }
}
