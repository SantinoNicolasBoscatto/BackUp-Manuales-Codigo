﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer.Example2
{
    public class Bidder : IBidder
    {
        private string _name;

        public Bidder(string name)
        {
            _name = name;
        }
        public void Update(AuctionItem item)
        {
            Console.WriteLine($"{_name} notified. New highest bid on {item.Name} is {item.Price}");
        }
    }
}
