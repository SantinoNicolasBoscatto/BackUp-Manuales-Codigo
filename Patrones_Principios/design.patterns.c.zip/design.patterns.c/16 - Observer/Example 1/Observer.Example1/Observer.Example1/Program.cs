﻿using Observer.Example1;

WeatherStation weatherStation = new WeatherStation();
TV currentDisplay = new TV();

weatherStation.RegisterObserver(currentDisplay);

weatherStation.SetMeasurements(80, 65, 30.4f);

weatherStation.SetMeasurements(82, 70, 29.2f);

weatherStation.SetMeasurements(78, 90, 29.2f);