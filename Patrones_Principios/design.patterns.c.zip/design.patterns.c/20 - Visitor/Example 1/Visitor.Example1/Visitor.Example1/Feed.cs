﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visitor.Example1
{
    public class Feed : IAnimalOperation
    {
        public void VisitLion(Lion lion)
        {
            Console.WriteLine("The lion has been fed.");
        }

        public void VisitMonkey(Monkey monkey)
        {
            Console.WriteLine("The monkey has been fed.");
        }
    }
}
