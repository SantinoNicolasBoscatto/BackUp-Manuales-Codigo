﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visitor.Example1
{
    public class Monkey : IAnimal
    {
        public void Accept(IAnimalOperation operation)
        {
            operation.VisitMonkey(this);
        }
    }
}
