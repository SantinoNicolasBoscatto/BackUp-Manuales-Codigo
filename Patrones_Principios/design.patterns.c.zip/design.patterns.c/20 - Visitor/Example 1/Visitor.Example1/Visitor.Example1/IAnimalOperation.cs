﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visitor.Example1
{
    public interface IAnimalOperation
    {
        void VisitLion(Lion lion);
        void VisitMonkey(Monkey monkey);
    }
}
