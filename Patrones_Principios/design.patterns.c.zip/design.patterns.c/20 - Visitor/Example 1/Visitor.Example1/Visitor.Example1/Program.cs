﻿using Visitor.Example1;

var animals = new List<IAnimal>
{
    new Lion(),
    new Monkey()
};

var operations = new List<IAnimalOperation>
{
    new Feed(),
    new MedicalCheck()
};

foreach (var animal in animals)
{
    foreach (var operation in operations)
    {
        animal.Accept(operation);
    }
}