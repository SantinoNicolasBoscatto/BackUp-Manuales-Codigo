﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Visitor.Example2
{
    public interface IProductVisitor
    {
        void Visit(TV tv);
        void Visit(Phone phone);
        void Visit(Computer computer);
    }
}
