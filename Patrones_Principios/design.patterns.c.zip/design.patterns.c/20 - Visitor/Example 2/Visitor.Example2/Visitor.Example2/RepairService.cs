﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visitor.Example2
{
    public class RepairService : IProductVisitor
    {
        public void Visit(TV tv)
        {
            Console.WriteLine("Repairing a TV.");
        }

        public void Visit(Phone phone)
        {
            Console.WriteLine("Repairing a Phone.");
        }

        public void Visit(Computer computer)
        {
            Console.WriteLine("Repairing a Computer.");
        }
    }
}
