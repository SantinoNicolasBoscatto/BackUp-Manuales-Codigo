﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visitor.Example2
{
    public class Phone : IProduct
    {
        public void Accept(IProductVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
}
