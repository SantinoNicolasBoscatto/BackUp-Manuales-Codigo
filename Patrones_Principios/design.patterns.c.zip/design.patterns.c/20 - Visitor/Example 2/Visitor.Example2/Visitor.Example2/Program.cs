﻿using Visitor.Example2;

var tv = new TV();
var phone = new Phone();
var computer = new Computer();
var repairService = new RepairService();

tv.Accept(repairService);
phone.Accept(repairService);
computer.Accept(repairService);
