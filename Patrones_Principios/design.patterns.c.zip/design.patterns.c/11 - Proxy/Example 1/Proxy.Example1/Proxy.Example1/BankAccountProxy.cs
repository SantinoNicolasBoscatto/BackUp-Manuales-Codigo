﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy.Example1
{
    public class BankAccountProxy : IBankAccount
    {
        private BankAccount _bankAccount;

        public BankAccountProxy(BankAccount bankAccount)
        {
            _bankAccount = bankAccount;
        }
        public void Deposit(int amount)
        {
            _bankAccount.Deposit(amount);
        }

        public int GetBalance()
        {
            return _bankAccount.GetBalance();
        }

        public bool Withdraw(int amount)
        {
            if (amount > 10000)
            {
                Console.WriteLine("You need manager approval for withdrawals over 10000");
                return false;
            }
            else
            {
                return _bankAccount.Withdraw(amount);
            }
        }
    }
}
