﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator.Example2
{
    public abstract class Aircraft
    {
        protected IAirTrafficControl _tower;
        protected string _name;

        public Aircraft(IAirTrafficControl tower, string name)
        {
            _tower = tower;
            _name = name;

            if (_tower is Tower concreteTower)
                concreteTower.RegisterAircraft(this);
        }

        public void SendMessage(string message)
        {
            _tower.SendMessage(this, message);
        }

        public void ReceiveMessage(string message)
        {
            Console.WriteLine($"{_name} received message: {message}");
        }
    }
}
