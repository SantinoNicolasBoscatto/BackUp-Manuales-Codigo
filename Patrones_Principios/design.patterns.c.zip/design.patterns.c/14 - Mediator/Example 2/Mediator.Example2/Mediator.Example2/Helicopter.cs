﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator.Example2
{
    public class Helicopter : Aircraft
    {
        public Helicopter(IAirTrafficControl tower, string name) : base(tower, name)
        {
        }
    }
}
