﻿using Mediator.Example2;

IAirTrafficControl tower = new Tower();
Aircraft airplane1 = new Airplane(tower, "Airplane1");
Aircraft airplane2 = new Airplane(tower, "Airplane2");

airplane1.SendMessage("Hello from Airplane1!");