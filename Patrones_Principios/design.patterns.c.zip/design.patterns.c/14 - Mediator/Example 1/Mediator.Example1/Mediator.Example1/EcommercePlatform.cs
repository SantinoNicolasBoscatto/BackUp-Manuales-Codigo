﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator.Example1
{
    public class EcommercePlatform : IMediator
    {
        private ShoppingCart _shoppingCart;
        private InventorySystem _inventorySystem;

        public EcommercePlatform(ShoppingCart shoppingCart, 
            InventorySystem inventorySystem)
        {
            _shoppingCart = shoppingCart;
            _inventorySystem = inventorySystem;
        }

        public void Notify(object sender, string eventCode)
        {
            if (sender is ShoppingCart)
            {
                _inventorySystem.CheckItemAvailability(eventCode);
            }
        }
    }
}
