﻿using Mediator.Example1;

var inventorySystem = new InventorySystem(null);
var shoppingCart = new ShoppingCart(null);

var ecommercePlatform = new EcommercePlatform(shoppingCart, inventorySystem);

inventorySystem.SetMediator(ecommercePlatform);
shoppingCart.SetMediator(ecommercePlatform);

shoppingCart.AddItem("Apple");
shoppingCart.AddItem("Orange");