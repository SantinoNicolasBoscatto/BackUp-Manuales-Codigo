﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator.Example1
{
    public class InventorySystem
    {
        private IMediator _mediator;

        public InventorySystem(IMediator mediator)
        {
            _mediator = mediator;
        }
        public void SetMediator(IMediator mediator)
        {
            _mediator = mediator;
        }

        public void CheckItemAvailability(string item)
        {
            Console.WriteLine($"Checking how many {item} are available...");
        }

    }
}
