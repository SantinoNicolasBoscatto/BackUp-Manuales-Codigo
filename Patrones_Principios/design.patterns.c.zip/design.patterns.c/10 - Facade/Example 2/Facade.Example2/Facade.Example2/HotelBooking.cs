﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Example2
{
    public class HotelBooking
    {
        public void BookHotel(string destination)
        {
            Console.WriteLine($"Hotel booked in {destination}");
        }
    }
}
