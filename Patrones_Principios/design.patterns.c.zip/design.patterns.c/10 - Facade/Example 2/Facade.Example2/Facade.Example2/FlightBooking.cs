﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Example2
{
    public class FlightBooking
    {
        public void BookFlight(string destination)
        {
            Console.WriteLine($"Flight booked to {destination}");
        }
    }
}
