﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Example2
{
    public class CarRental
    {
        public void RentCar(string destination)
        {
            Console.WriteLine($"Car rented in {destination}");
        }
    }
}
