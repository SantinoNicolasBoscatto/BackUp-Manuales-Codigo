﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Example2
{
    public class TravelFacade
    {
        private FlightBooking _flightBooking;
        private HotelBooking _hotelBooking;
        private CarRental _carRental;

        public TravelFacade(FlightBooking flightBooking,
            HotelBooking hotelBooking, 
            CarRental carRental)
        {
            _flightBooking = flightBooking;
            _hotelBooking = hotelBooking;
            _carRental = carRental;
        }

        public void ArrangeTrip(string destination)
        {
            Console.WriteLine($"Arranging trip to {destination}");

            _flightBooking.BookFlight(destination);
            _hotelBooking.BookHotel(destination);
            _carRental.RentCar(destination);
        }
    }
}
