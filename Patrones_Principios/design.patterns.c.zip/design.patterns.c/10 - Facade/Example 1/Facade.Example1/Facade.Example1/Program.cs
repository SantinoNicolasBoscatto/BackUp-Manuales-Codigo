﻿using Facade.Example1;

DvdPlayer dvdPlayer = new DvdPlayer();
Projector projector = new Projector();
Speakers speakers = new Speakers();

HomeTheaterFacade homeTheater = new HomeTheaterFacade(dvdPlayer, projector, speakers);
homeTheater.WatchMovie("Inception");

Console.WriteLine("Wait two hours");

homeTheater.EndMovie();