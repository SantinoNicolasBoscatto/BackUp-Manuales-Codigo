﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memento.Example1
{
    public class Game
    {
        public GameState CurrentState { get; set; }

        public GameMemento SaveGame()
        {
            return new GameMemento(CurrentState);
        }

        public void LoadGame(GameMemento memento)
        {
            CurrentState = memento.State;
        }
    }
}
