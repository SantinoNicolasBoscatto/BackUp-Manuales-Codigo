﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memento.Example1
{
    public class GameMemento
    {
        public GameState State { get; private set; }

        public GameMemento(GameState gameState)
        {
            State = gameState;
        }

    }
}
