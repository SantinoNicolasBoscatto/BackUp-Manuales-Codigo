﻿using Memento.Example2;

Repository repo = new Repository();
Git git = new Git();

repo.Code = "Initial code";
git.Commit(repo);

Console.WriteLine(repo.Code);

repo.Code = "Code after first change";
git.Commit(repo);

Console.WriteLine(repo.Code);

repo.Code = "Code after second change";
git.Commit(repo);

Console.WriteLine(repo.Code);

git.Revert(repo);
Console.WriteLine(repo.Code);
