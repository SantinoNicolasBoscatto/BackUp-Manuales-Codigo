﻿using Bridge.Example1;

IFormat mp3Format = new MP3();
MusicPlayer player = new DesktopPlayer(mp3Format);
player.Play("song.mp3");

IFormat wavFormat = new WAV();
player = new MobilePlayer(wavFormat);
player.Play("song.wav");