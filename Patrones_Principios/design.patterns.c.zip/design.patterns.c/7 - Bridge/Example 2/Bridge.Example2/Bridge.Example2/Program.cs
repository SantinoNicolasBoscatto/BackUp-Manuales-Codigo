﻿using Bridge.Example2;

Vehicle carWithPetrolEngine = new Car(new PetrolEngine());
carWithPetrolEngine.Drive();

Vehicle busWithElectricEngine = new Bus(new ElectricEngine());
busWithElectricEngine.Drive();