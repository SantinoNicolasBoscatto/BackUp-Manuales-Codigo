﻿using Singleton.Example1;

MySingleton singleton = MySingleton.GetInstance();
