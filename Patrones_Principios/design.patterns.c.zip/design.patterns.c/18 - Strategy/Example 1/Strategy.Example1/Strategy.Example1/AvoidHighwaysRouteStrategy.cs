﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.Example1
{
    public class AvoidHighwaysRouteStrategy : IRouteStrategy
    {
        public string CalculateRoute(string A, string B)
        {
            return "Route avoiding highways calculated";
        }
    }
}
