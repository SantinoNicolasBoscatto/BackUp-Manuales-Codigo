﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.Example1
{
    public class Navigator
    {
        private IRouteStrategy _strategy;

        public Navigator(IRouteStrategy strategy)
        {
            _strategy = strategy;
        }

        public void SetStrategy(IRouteStrategy strategy)
        {
            _strategy = strategy;
        }

        public string ExecuteStrategy(string A, string B)
        {
            return _strategy.CalculateRoute(A, B);
        }
    }
}
