﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.Example2
{
    public class BikeStrategy : ITransportModeStrategy
    {
        public void GoToWork()
        {
            Console.WriteLine("Going to work by bike. It's eco-friendly and healthy!");
        }
    }
}
