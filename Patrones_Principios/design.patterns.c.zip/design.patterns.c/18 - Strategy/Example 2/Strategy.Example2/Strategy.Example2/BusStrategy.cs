﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy.Example2
{
    public class BusStrategy : ITransportModeStrategy
    {
        public void GoToWork()
        {
            Console.WriteLine("Going to work by bus. It's economical and convenient.");
        }
    }
}
