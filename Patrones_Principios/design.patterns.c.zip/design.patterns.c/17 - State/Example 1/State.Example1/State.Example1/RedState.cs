﻿namespace State.Example1
{
    public class RedState : IState
    {
        public void Handle(StateContext context)
        {
            Console.WriteLine("Red light - Stop!");
            context.State = new GreenState();
        }
    }
}