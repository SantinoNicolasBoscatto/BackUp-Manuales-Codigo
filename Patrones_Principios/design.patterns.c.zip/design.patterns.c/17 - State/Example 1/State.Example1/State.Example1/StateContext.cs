﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State.Example1
{
    public class StateContext
    {
        public IState State { get; set; }

        public StateContext()
        {
            State = new GreenState();
        }

        public void Request()
        {
            State.Handle(this);
        }

    }
}
