﻿namespace State.Example1
{
    public class YellowState : IState
    {
        public void Handle(StateContext context)
        {
            Console.WriteLine("Yellow light - Prepare to stop!");
            context.State = new RedState();
        }
    }
}