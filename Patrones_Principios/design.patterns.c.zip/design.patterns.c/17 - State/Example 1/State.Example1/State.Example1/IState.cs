﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State.Example1
{
    public interface IState
    {
        void Handle(StateContext context);
    }
}
