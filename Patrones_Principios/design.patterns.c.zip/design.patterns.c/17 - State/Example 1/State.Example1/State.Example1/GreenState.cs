﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State.Example1
{
    public class GreenState : IState
    {
        public void Handle(StateContext context)
        {
            Console.WriteLine("Green light - Go!");
            context.State = new YellowState();
        }
    }
}
