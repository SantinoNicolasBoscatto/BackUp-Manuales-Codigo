﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command.Example2
{
    public class SmartTV
    {
        public void OpenAmazon()
        {
            Console.WriteLine("Amazon is opened");
        }
        public void OpenNetflix()
        {
            Console.WriteLine("Netflix is opened");
        }
    }
}
