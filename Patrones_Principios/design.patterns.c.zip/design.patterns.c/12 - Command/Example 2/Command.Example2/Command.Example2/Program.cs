﻿using Command.Example2;

SmartTV tv = new SmartTV();

RemoteControl remote = new RemoteControl();

remote.SetCommand(new AmazonCommand(tv));
remote.PressButton();

remote.SetCommand(new NetflixCommand(tv));
remote.PressButton();