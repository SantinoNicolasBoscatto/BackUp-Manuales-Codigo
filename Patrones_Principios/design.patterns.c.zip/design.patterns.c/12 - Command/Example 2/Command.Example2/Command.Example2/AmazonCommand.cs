﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command.Example2
{
    public class AmazonCommand : ICommand
    {
        private SmartTV _tv;

        public AmazonCommand(SmartTV tv)
        {
            _tv = tv;
        }
        public void Execute()
        {
            _tv.OpenAmazon();
        }
    }
}
