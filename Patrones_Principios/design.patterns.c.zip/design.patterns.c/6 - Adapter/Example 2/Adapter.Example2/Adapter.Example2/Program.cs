﻿using Adapter.Example2;

LegacyDatabase legacyDatabase = new LegacyDatabase();
DatabaseAdapter adapter = new DatabaseAdapter(legacyDatabase);

NewSystem newSystem = new NewSystem(adapter);

newSystem.SaveData("Important data");
newSystem.LoadData();