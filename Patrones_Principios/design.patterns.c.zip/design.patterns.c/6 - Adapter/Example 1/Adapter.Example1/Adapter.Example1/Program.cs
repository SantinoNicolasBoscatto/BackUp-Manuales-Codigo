﻿using Adapter.Example1;

CommunicationSystem communicationSystem = new CommunicationSystem();
EnglishSpeaker englishSpeaker = new EnglishSpeaker();
communicationSystem.StartConversation(englishSpeaker, "How are you?", "I'm fine, thank you! ");

SpanishSpeaker spanishSpeaker = new SpanishSpeaker();
Translator translator = new Translator(spanishSpeaker);
communicationSystem.StartConversation(translator, "¿Cómo estás?", "¡Estoy bien, gracias!");