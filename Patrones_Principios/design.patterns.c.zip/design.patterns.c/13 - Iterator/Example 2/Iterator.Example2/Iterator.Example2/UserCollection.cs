﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.Example2
{
    public class UserCollection : ICollection
    {
        private readonly List<User> _users;

        public UserCollection(List<User> users)
        {
            _users = users;
        }
    
        public IFacebookIterator CreateIterator()
        {
            return new FacebookIterator(_users);
        }
    }
}
