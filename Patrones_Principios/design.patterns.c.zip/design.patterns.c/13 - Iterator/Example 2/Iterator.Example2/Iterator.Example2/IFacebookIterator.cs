﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.Example2
{
    public interface IFacebookIterator
    {
        User CurrentUser();
        bool HasNextUser();
        User NextUser();
    }
}
