﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.Example2
{
    public class Client
    {
        public void ShowUsers(ICollection collection)
        {
            var iterator = collection.CreateIterator();
            while (iterator.HasNextUser())
            {
                var user = iterator.NextUser();
                Console.WriteLine(user.Name);
            }
        }
    }
}
