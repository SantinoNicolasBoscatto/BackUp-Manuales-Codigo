﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.Example2
{
    public class FacebookIterator : IFacebookIterator
    {
        private List<User> _users;
        private int _position = -1;
        public FacebookIterator(List<User> users)
        {
            _users = users;
        }

        public User CurrentUser()
        {
            if (_position < 0 || _position >= _users.Count)
                throw new InvalidOperationException();

            return _users[_position];
        }

        public bool HasNextUser()
        {
            return _position + 1 < _users.Count;
        }

        public User NextUser()
        {
            if (!HasNextUser())
                throw new InvalidOperationException();

            _position++;

            return _users[_position];
        }
    }
}
