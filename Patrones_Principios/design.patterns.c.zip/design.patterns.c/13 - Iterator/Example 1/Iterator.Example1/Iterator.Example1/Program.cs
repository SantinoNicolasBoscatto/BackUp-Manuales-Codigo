﻿using Iterator.Example1;

var library = new Library();
var iterator = library.CreateIterator();

while (iterator.HasNext())
{
    var book = iterator.Next();
    Console.WriteLine($"Title: {book.Title}, Author: {book.Author}");
}