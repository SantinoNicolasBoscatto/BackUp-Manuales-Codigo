﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.Example1
{
    public class Library : ICollection<Book>
    {
        private List<Book> _books;

        public Library()
        {
            _books = new List<Book>()
            {
                new Book("1984", "George Orwell"),
                new Book("To Kill a Mockingbird", "Harper Lee"),
                new Book("Moby-Dick", "Herman Melville")
            };
        }

        public IIterator<Book> CreateIterator()
        {
            return new BookIterator(_books);
        }
    }
}
